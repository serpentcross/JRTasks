package utils

import (
	"time"
)

func GetDaysInMonth(year, month int) int {
	location := time.UTC
	date := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, location)
	nextMonth := date.AddDate(0, 1, 0)
	return int(nextMonth.Sub(date).Hours() / 24)
}
