package utils

import (
	"fmt"
	"testing"
)

func TestDaysInFebForLeapYear(t *testing.T) {

	year := 2024
	month := 2
	expected := 29

	got := GetDaysInMonth(year, month)
	if got != expected {
		t.Errorf("GetDaysInMonth(%d, %d) = %d; expected %d", year, month, got, expected)
	}

}

func TestDaysInJanMarMayJunAugOctDec(t *testing.T) {

	year := 2024
	expected := 31
	months := []int{1, 3, 5, 7, 8, 10, 12}

	iterateOverMonthsArray(t, months, year, expected)

}

func TestDaysInAprJunOctDec(t *testing.T) {

	year := 2024
	expected := 30
	months := []int{4, 6, 9, 11}

	iterateOverMonthsArray(t, months, year, expected)

}

func TestDaysInFebForNormalYear(t *testing.T) {

	year := 2025
	month := 2
	expected := 28

	got := GetDaysInMonth(year, month)
	if got != expected {
		t.Errorf("GetDaysInMonth(%d, %d) = %d; expected %d", year, month, got, expected)
	}

}

func iterateOverMonthsArray(t *testing.T, months []int, year int, expected int) {
	for _, tt := range months {
		t.Run(
			fmt.Sprintf("Year: %d Month: %d", year, tt),
			func(t *testing.T) {
				got := GetDaysInMonth(year, tt)
				if got != expected {
					t.Errorf("getDaysInMonth( %d, %d) = %d; expected %d", year, months, got, expected)
				}
			})
	}
}
