package main

import (
	"fmt"
	"multi_main_project/cmd/savings"
)

func main() {

	years := []int{2024, 2025}

	annualInterestRate := 2.99

	profit, err := savings.CalculateProfitWithInterest(2025, 5, annualInterestRate)

	if err != nil {
		fmt.Println("Error:", err)
	} else {
		fmt.Printf("Common profit for %d year with a rate %.2f% % rates: %.2f $\n", years, annualInterestRate, profit)
	}

}
