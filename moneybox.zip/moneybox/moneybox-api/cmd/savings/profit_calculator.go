package savings

import (
	"fmt"
	"multi_main_project/cmd/utils"
	"time"
)

func CalculateMonthlyProfit(year, month int) (int, error) {
	if month < 1 || month > 12 {
		return 0, fmt.Errorf("Error! The given month: %d is incorrect", month)
	}
	daysInMonth := utils.GetDaysInMonth(year, month)
	sum := daysInMonth * (1 + daysInMonth) / 2
	return sum, nil
}

func CalculateYearlyProfit(year int) (int, error) {
	totalSavings := 0
	for month := 1; month <= 12; month++ {
		monthlySavings, err := CalculateMonthlyProfit(year, month)
		if err != nil {
			return 0, err
		}
		totalSavings += monthlySavings
	}
	return totalSavings, nil
}

func CalculateProfitWithInterest(startYear, duration int, annualInterestRate float64) (float64, error) {

	totalProfit := 0.0
	currentSavings := 0.0
	minimumBalance := 0.0

	monthlyInterestRate := annualInterestRate / 12 / 100

	endYear := startYear + duration

	for year := startYear; year <= endYear; year++ {

		fmt.Printf("%d year \n", year)
		fmt.Println("**************************************************")

		yearProfit := 0.0

		for month := 1; month <= 12; month++ {

			monthlySavings, err := CalculateMonthlyProfit(year, month)

			if err != nil {
				return 0, err
			}

			monthlyProfit := minimumBalance * monthlyInterestRate
			yearProfit += monthlyProfit
			totalProfit += monthlyProfit

			monthName := time.Date(0, time.Month(month), 1, 0, 0, 0, 0, time.UTC).Format("Jan")

			fmt.Printf(" %s | min amount: %.2f $ | Profit: %.2f $\n", monthName, minimumBalance, monthlyProfit)

			currentSavings = minimumBalance + monthlyProfit + float64(monthlySavings)

			minimumBalance = currentSavings
		}

		fmt.Println("----------------------------------------------------------")
		fmt.Printf("The final profit for %d year: %.2f $\n", year, yearProfit)
		fmt.Println("----------------------------------------------------------")

		minimumBalance = currentSavings
	}

	return totalProfit, nil
}
