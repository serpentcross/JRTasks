package savings

import (
	"testing"
)

func TestCalculateMonthlyProfitJanMarMayJulAugOctDec(t *testing.T) {
	year := 2024
	expected := 496
	months := []int{1, 3, 5, 7, 8, 10, 12}
	iterateThroughMonths(t, months, year, expected)
}

func TestCalculateMonthlyProfitAprJunSepNov(t *testing.T) {
	year := 2024
	expected := 465
	months := []int{4, 6, 9, 11}
	iterateThroughMonths(t, months, year, expected)
}

func TestCalculateMonthlyProfitFebLeap(t *testing.T) {
	conductTheTest(t, 2024, 435, 2)
}

func TestCalculateMonthlyProfitFebNormal(t *testing.T) {
	conductTheTest(t, 2025, 406, 2)
}

func conductTheTest(t *testing.T, year int, month int, expected int) {
	result, err := CalculateMonthlyProfit(year, month)
	if err != nil {
		t.Errorf("Error in CalculateYearlyProfit for month %d: %v", month, err)
	}
	if result != expected {
		t.Errorf("The result is incorrect for %d: year! Expected %d, got %d", month, expected, result)
	}
}

func TestCalculateYearlyProfit(t *testing.T) {

	tests := []struct {
		year     int
		expected int
	}{
		{2024, 5767},
		{2023, 5738},
	}

	for _, test := range tests {
		result, err := CalculateYearlyProfit(test.year)
		if err != nil {
			t.Errorf("Error in CalculateYearlyProfit for year %d: %v", test.year, err)
			continue
		}
		if result != test.expected {
			t.Errorf("The result is incorrect for %d: year! Expected %d, got %d", test.year, test.expected, result)
		}
	}

}

func iterateThroughMonths(t *testing.T, months []int, year int, expected int) {
	for _, month := range months {
		result, err := CalculateMonthlyProfit(year, month)
		if err != nil {
			t.Errorf("Error in CalculateYearlyProfit for month %d: %v", month, err)
			continue
		}
		if result != expected {
			t.Errorf("The result is incorrect for %d: year! Expected %d, got %d", month, expected, result)
		}
	}
}
