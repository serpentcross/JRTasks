function msg() {
    alert("Hello!");
}

function addbox() {
    document.getElementById('added-amount').style.display =
        document.getElementById('progressive').checked ? 'none' : 'block';
}